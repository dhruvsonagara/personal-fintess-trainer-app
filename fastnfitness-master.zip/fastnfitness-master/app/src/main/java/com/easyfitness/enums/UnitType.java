package com.easyfitness.enums;

public enum UnitType {
    WEIGHT,
    DISTANCE,
    SIZE,
    PERCENTAGE,
    NONE
}
